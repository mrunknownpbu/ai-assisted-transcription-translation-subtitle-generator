# Production Runbook

## Hardware

### NVIDIA
Install NVIDIA driver + NVIDIA Container Toolkit on the host. Start with:
`docker compose -f docker-compose.yml -f docker-compose.nvidia.yml up -d --build`.

### AMD
Expose ROCm devices to the container and use an image/dependency build containing a ROCm-compatible ASR engine. The hardware detector records ROCm; engine selection remains configuration-driven.

### CPU
Use the default compose file. Reduce `WORKER_CONCURRENCY` and choose a smaller Whisper model for constrained hosts.

## Failure handling

- **No audio streams:** job fails; inspect source.
- **Primary ASR unavailable:** router records the error and tries each configured fallback.
- **Translation unavailable:** job fails unless a deliberate non-API provider is configured. Identity translation is included for deterministic tests, not production translation.
- **OOM:** reduce concurrency/model/compute type and review hardware profile.
- **QC failure:** outputs are not considered valid; inspect stage logs.

## Source safety

`/media` is read-only. Temporary extracted WAV files live under `/work`. Never mount source media read-write.

## Existing subtitles

The implementation intentionally does not read subtitle streams as ASR input. Future evidence extraction can inspect them separately and label them `evidence`, but they must not influence canonical transcript content.

## Backups

Back up `/data/db/subtitle_ai.db` and output storage. The database is the audit trail for jobs, decisions, provenance and hardware profiles.
