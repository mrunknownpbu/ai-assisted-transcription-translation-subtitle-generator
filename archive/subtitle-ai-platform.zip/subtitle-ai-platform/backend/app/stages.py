from abc import ABC,abstractmethod
from pathlib import Path
import re,statistics
from .media import extract_audio

class Stage(ABC):
    name="stage"
    @abstractmethod
    def run(self, ctx): ...

def rank_audio_streams(info):
    # Lightweight ranking from metadata plus measured audio features. It is a ranking signal, never ground truth.
    ranked=[]
    for s in info["audio_streams"]:
        ch=s.get("channels",0) or 0; sr=s.get("sample_rate",0) or 0; br=s.get("bit_rate",0) or 0
        score=0.0
        if ch: score+=min(ch,2)*0.5
        if sr>=16000: score+=1
        if br: score+=min(float(br)/128000,1)
        ranked.append({"stream_index":s["index"],"score":score,"metadata":s,"reason":"metadata pre-rank; audio analysis follows after extraction"})
    return sorted(ranked,key=lambda x:x["score"],reverse=True)

class WhisperEngine(ABC):
    name="abstract"
    @abstractmethod
    def transcribe(self,audio,language=None): ...

class FasterWhisperEngine(WhisperEngine):
    name="faster-whisper"
    def __init__(self,model="small",device="auto",compute_type="auto"):
        self.model=model; self.device=device; self.compute_type=compute_type
        self._model=None
    def transcribe(self,audio,language=None):
        from faster_whisper import WhisperModel
        if self._model is None:
            device="cuda" if self.device=="auto" else self.device
            ct=self.compute_type if self.compute_type!="auto" else ("float16" if device=="cuda" else "int8")
            self._model=WhisperModel(self.model,device=device,compute_type=ct)
        segs,meta=self._model.transcribe(audio,language=language,word_timestamps=True,vad_filter=True,condition_on_previous_text=False)
        out=[]
        for i,s in enumerate(segs):
            words=[]
            for w in (s.words or []): words.append({"text":w.word,"start":w.start,"end":w.end,"confidence":getattr(w,"probability",None)})
            out.append({"id":f"s{i:06d}","start":s.start,"end":s.end,"text":s.text.strip(),"words":words,"confidence":statistics.fmean([w["confidence"] for w in words if w["confidence"] is not None]) if words else None})
        return {"language":meta.language,"segments":out,"text":" ".join(x["text"] for x in out),"engine":self.name,"model":self.model}

class VoskEngine(WhisperEngine):
    name="vosk"
    def transcribe(self,audio,language=None):
        # Adapter contract. A deployed Vosk model is required; language selects model externally.
        from vosk import Model, KaldiRecognizer
        import wave, json as j
        model_path=f"/models/vosk/{language or 'auto'}"
        model=Model(model_path)
        wf=wave.open(audio,"rb"); rec=KaldiRecognizer(model,wf.getframerate()); rec.SetWords(True)
        words=[]
        while True:
            data=wf.readframes(4000)
            if not data: break
            if rec.AcceptWaveform(data): words.extend(j.loads(rec.Result()).get("result",[]))
        words.extend(j.loads(rec.FinalResult()).get("result",[]))
        seg={"id":"s000000","start":words[0]["start"] if words else 0,"end":words[-1]["end"] if words else 0,"text":" ".join(w.get("word","") for w in words),"words":[{"text":w.get("word",""),"start":w["start"],"end":w["end"],"confidence":w.get("conf")} for w in words],"confidence":statistics.fmean([w.get("conf",0) for w in words]) if words else None}
        return {"language":language or "unknown","segments":[seg],"text":seg["text"],"engine":self.name,"model":"vosk"}

class WhisperAPIEngine(WhisperEngine):
    name="whisper-api"
    def __init__(self,client=None): self.client=client
    def transcribe(self,audio,language=None):
        if self.client is None: raise RuntimeError("Whisper API client is not configured")
        with open(audio,"rb") as f:
            r=self.client.audio.transcriptions.create(model="whisper-1",file=f,response_format="verbose_json",timestamp_granularities=["word","segment"],language=language)
        return {"language":getattr(r,"language",language or "unknown"),"segments":[s.model_dump() for s in getattr(r,"segments",[])],"text":r.text,"engine":self.name,"model":"whisper-1"}

class ASRRouter:
    def __init__(self, engines): self.engines=engines
    def transcribe(self,audio,language=None):
        errors=[]
        for engine in self.engines:
            try:
                result=engine.transcribe(audio,language); result["attempts"]=errors+[engine.name]; return result
            except Exception as e: errors.append({"engine":engine.name,"error":str(e)})
        raise RuntimeError(f"All ASR engines failed: {errors}")

def hallucination_defense(transcript,vad_regions=None,min_conf=0.20,max_repeat=6):
    # Recall-first: suppress only strong evidence. Low confidence alone is never sufficient.
    decisions=[]; kept=[]
    for seg in transcript["segments"]:
        txt=re.sub(r"\s+"," ",seg["text"]).strip()
        tokens=txt.lower().split(); repetition=False
        if len(tokens)>=max_repeat and len(set(tokens))<=max(1,len(tokens)//3): repetition=True
        confs=[w["confidence"] for w in seg.get("words",[]) if w.get("confidence") is not None]
        mean=statistics.fmean(confs) if confs else None
        # No VAD region or confidence cutoff causes suppression by itself.
        if repetition and mean is not None and mean < min_conf:
            decisions.append({"segment_id":seg["id"],"decision":"suppress","reason":"repetition + low confidence","threshold":f"mean_conf<{min_conf}, unique_ratio<=0.333"})
            continue
        decisions.append({"segment_id":seg["id"],"decision":"keep","reason":"no positive hallucination evidence","threshold":f"mean_conf<{min_conf} is insufficient alone"})
        kept.append(seg)
    transcript=dict(transcript); transcript["segments"]=kept; transcript["text"]=" ".join(s["text"] for s in kept); return transcript,decisions

def conservative_normalize(t):
    import copy
    out=copy.deepcopy(t)
    for s in out["segments"]:
        s["original_text"]=s["text"]; s["text"]=re.sub(r"[ \t]+"," ",s["text"]).strip()
    return out

def translate_segments(transcript,target_language,provider):
    return provider.translate(transcript,target_language)

def project_target_segments(transcript,translations):
    # translations may contain arbitrary N:M source IDs; timing is min/max of mapped source word timestamps.
    result=[]
    for i,t in enumerate(translations):
        ids=t["source_ids"]; src=[s for s in transcript["segments"] if s["id"] in ids]
        words=[w for s in src for w in s.get("words",[])]
        if not words: raise ValueError("translation segment has no source timing evidence")
        result.append({"id":f"t{i:06d}","start":min(w["start"] for w in words),"end":max(w["end"] for w in words),"text":t["text"],"source_ids":ids})
    return result
