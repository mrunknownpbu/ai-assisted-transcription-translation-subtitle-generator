import hashlib,json,subprocess
from pathlib import Path

def inspect_media(path:str)->dict:
    cmd=["ffprobe","-v","error","-show_entries","format=format_name,duration,size:stream=index,codec_type,codec_name,codec_long_name,profile,channels,channel_layout,sample_rate,bit_rate,duration:stream_tags=language,title","-of","json",path]
    data=json.loads(subprocess.check_output(cmd,text=True))
    streams=data.get("streams",[])
    audio=[s for s in streams if s.get("codec_type")=="audio"]
    return {"path":path,"format":data.get("format",{}),"streams":streams,"audio_streams":audio}

def stream_identity(path:str, stream:dict)->str:
    h=hashlib.sha256()
    # Hash only deterministic stream identity material plus a bounded content sample.
    fields={k:stream.get(k) for k in ("index","codec_name","profile","channels","channel_layout","sample_rate","bit_rate","duration")}
    h.update(json.dumps(fields,sort_keys=True).encode())
    cmd=["ffmpeg","-v","error","-i",path,"-map",f"0:{stream['index']}","-t","30","-f","s16le","-ac","1","-ar","16000","pipe:1"]
    p=subprocess.Popen(cmd,stdout=subprocess.PIPE)
    sample=p.stdout.read(16000*2*30); p.kill()
    h.update(sample)
    return h.hexdigest()

def extract_audio(path, stream_index, out):
    subprocess.run(["ffmpeg","-y","-v","error","-i",path,"-map",f"0:{stream_index}","-vn","-ac","1","-ar","16000","-c:a","pcm_s16le",out],check=True)
