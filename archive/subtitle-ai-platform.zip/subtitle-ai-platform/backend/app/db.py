from datetime import datetime, timezone
from sqlalchemy import create_engine, String, Integer, Float, Text, DateTime, ForeignKey, JSON
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker
from .config import settings

def now(): return datetime.now(timezone.utc)
engine=create_engine(settings.database_url, connect_args={"check_same_thread":False})
SessionLocal=sessionmaker(bind=engine, expire_on_commit=False)
class Base(DeclarativeBase): pass
class Job(Base):
    __tablename__="jobs"
    id: Mapped[str]=mapped_column(String(64),primary_key=True)
    input_path: Mapped[str]=mapped_column(Text)
    selected_stream: Mapped[int|None]=mapped_column(Integer,nullable=True)
    source_language: Mapped[str|None]=mapped_column(String(64),nullable=True)
    target_language: Mapped[str]=mapped_column(String(128))
    status: Mapped[str]=mapped_column(String(32),default="queued")
    stage: Mapped[str|None]=mapped_column(String(64),nullable=True)
    progress: Mapped[float]=mapped_column(Float,default=0)
    priority: Mapped[int]=mapped_column(Integer,default=0)
    retries: Mapped[int]=mapped_column(Integer,default=0)
    outputs: Mapped[dict]=mapped_column(JSON,default=dict)
    hardware_profile: Mapped[dict]=mapped_column(JSON,default=dict)
    provenance: Mapped[dict]=mapped_column(JSON,default=dict)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
    updated_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now,onupdate=now)
class AudioCache(Base):
    __tablename__="audio_cache"
    cache_key: Mapped[str]=mapped_column(String(128),primary_key=True)
    media_path: Mapped[str]=mapped_column(Text)
    stream_index: Mapped[int]=mapped_column(Integer)
    codec: Mapped[str]=mapped_column(String(64))
    stream_hash: Mapped[str]=mapped_column(String(128))
    language: Mapped[str|None]=mapped_column(String(64),nullable=True)
    ranking: Mapped[float|None]=mapped_column(Float,nullable=True)
    evidence: Mapped[dict]=mapped_column(JSON,default=dict)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Decision(Base):
    __tablename__="decisions"
    id: Mapped[int]=mapped_column(Integer,primary_key=True,autoincrement=True)
    job_id: Mapped[str]=mapped_column(ForeignKey("jobs.id"))
    stage: Mapped[str]=mapped_column(String(64))
    decision: Mapped[str]=mapped_column(String(64))
    reason: Mapped[str]=mapped_column(Text)
    threshold: Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class LogEvent(Base):
    __tablename__="log_events"
    id: Mapped[int]=mapped_column(Integer,primary_key=True,autoincrement=True)
    job_id: Mapped[str]=mapped_column(String(64),index=True)
    stage: Mapped[str]=mapped_column(String(64))
    level: Mapped[str]=mapped_column(String(16))
    message: Mapped[str]=mapped_column(Text)
    data: Mapped[dict]=mapped_column(JSON,default=dict)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

def init_db(): Base.metadata.create_all(engine)
