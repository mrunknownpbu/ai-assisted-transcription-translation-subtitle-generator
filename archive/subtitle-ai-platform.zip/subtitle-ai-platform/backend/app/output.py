from pathlib import Path
import subprocess, json
def ts(x):
    ms=round(x*1000); h=ms//3600000; ms%=3600000; m=ms//60000; ms%=60000; s=ms//1000; ms%=1000
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
def write_srt(segs,path,prov):
    with open(path,"w",encoding="utf-8") as f:
        f.write("1\n") if False else None
        f.write(f"{{subtitle-ai provenance: {json.dumps(prov,ensure_ascii=False)}}}\n\n")
        for i,s in enumerate(segs,1): f.write(f"{i}\n{ts(s['start'])} --> {ts(s['end'])}\n{s['text']}\n\n")
def ts_vtt(x):
    ms=round(x*1000); h=ms//3600000; ms%=3600000; m=ms//60000; ms%=60000; s=ms//1000; ms%=1000
    return f"{h:02d}:{m:02d}:{s:02d}.{ms:03d}"
def write_vtt(segs,path,prov):
    with open(path,"w",encoding="utf-8") as f:
        f.write("WEBVTT\n"); f.write(f"NOTE subtitle-ai provenance: {json.dumps(prov,ensure_ascii=False)}\n\n")
        for i,s in enumerate(segs,1): f.write(f"{i}\n{ts_vtt(s['start'])} --> {ts_vtt(s['end'])}\n{s['text']}\n\n")
def burn_in(video,subs,out):
    subprocess.run(["ffmpeg","-y","-v","error","-i",video,"-vf",f"subtitles={subs}","-c:a","copy",out],check=True)
