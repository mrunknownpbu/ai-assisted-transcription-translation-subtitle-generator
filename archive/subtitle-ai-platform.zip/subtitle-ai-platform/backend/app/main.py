import uuid,asyncio,os
from pathlib import Path
from fastapi import FastAPI,HTTPException,UploadFile,File
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .db import init_db,SessionLocal,Job,LogEvent,Decision
from .models import JobCreate
from .hardware import detect_hardware
from .media import inspect_media
from .worker import Pipeline

app=FastAPI(title="Subtitle AI Platform",version="1.0.0")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_methods=["*"],allow_headers=["*"])
@app.on_event("startup")
def startup():
    init_db(); app.state.hardware=detect_hardware(); Path(settings.output_root).mkdir(parents=True,exist_ok=True); Path(settings.input_root).mkdir(parents=True,exist_ok=True); app.state.sem=asyncio.Semaphore(max(1,settings.worker_concurrency))
@app.get("/api/health")
def health(): return {"ok":True,"hardware":app.state.hardware}
@app.post("/api/upload")
async def upload(file: UploadFile=File(...)):
    name=Path(file.filename or "upload.bin").name
    dest=Path(settings.input_root)/name
    if dest.exists():
        stem=dest.stem; suffix=dest.suffix; i=1
        while dest.exists(): dest=Path(settings.input_root)/f"{stem}_{i}{suffix}"; i+=1
    with open(dest,"wb") as f:
        while chunk:=await file.read(1024*1024): f.write(chunk)
    return {"input_path":str(dest),"filename":dest.name}

@app.post("/api/inspect")
def inspect(path:str):
    if not os.path.exists(path): raise HTTPException(404,"Input path not found")
    return inspect_media(path)
@app.post("/api/jobs")
def create_job(req:JobCreate):
    if not os.path.exists(req.input_path): raise HTTPException(404,"Input path not found")
    jid=str(uuid.uuid4()); db=SessionLocal(); job=Job(id=jid,input_path=req.input_path,target_language=req.target_language,source_language=req.source_language,selected_stream=req.selected_stream,priority=req.priority,outputs=req.outputs,provenance={"replace_existing":req.replace_existing}); db.add(job); db.commit(); db.close()
    async def execute():
        async with app.state.sem:
            await asyncio.to_thread(Pipeline().run,jid)
    asyncio.create_task(execute()); return {"id":jid,"status":"queued"}
@app.get("/api/jobs")
def jobs():
    db=SessionLocal(); rows=db.query(Job).order_by(Job.priority.desc(),Job.created_at.desc()).all(); out=[{k:getattr(x,k) for k in ("id","input_path","selected_stream","source_language","target_language","status","stage","progress","priority","retries","outputs","hardware_profile")} for x in rows]; db.close(); return out
@app.get("/api/jobs/{jid}")
def job(jid:str):
    db=SessionLocal(); x=db.get(Job,jid);
    if not x: db.close(); raise HTTPException(404,"Job not found")
    out={k:getattr(x,k) for k in ("id","input_path","selected_stream","source_language","target_language","status","stage","progress","priority","retries","outputs","hardware_profile","provenance")}; db.close(); return out
@app.get("/api/jobs/{jid}/logs")
def logs(jid:str):
    db=SessionLocal(); rows=db.query(LogEvent).filter(LogEvent.job_id==jid).order_by(LogEvent.created_at).all(); out=[{"stage":r.stage,"level":r.level,"message":r.message,"data":r.data,"created_at":r.created_at} for r in rows]; db.close(); return out
@app.get("/api/jobs/{jid}/decisions")
def decisions(jid:str):
    db=SessionLocal(); rows=db.query(Decision).filter(Decision.job_id==jid).order_by(Decision.created_at).all(); out=[{"stage":r.stage,"decision":r.decision,"reason":r.reason,"threshold":r.threshold,"created_at":r.created_at} for r in rows]; db.close(); return out
@app.post("/api/jobs/{jid}/cancel")
def cancel(jid:str):
    db=SessionLocal(); x=db.get(Job,jid);
    if not x: db.close(); raise HTTPException(404,"Job not found")
    x.status="cancel_requested"; db.commit(); db.close(); return {"id":jid,"status":"cancel_requested"}

@app.post("/api/jobs/{jid}/retry")
def retry(jid:str):
    db=SessionLocal(); x=db.get(Job,jid)
    if not x: db.close(); raise HTTPException(404,"Job not found")
    if x.status not in ("failed","cancelled"): db.close(); raise HTTPException(409,"Only failed/cancelled jobs can be retried")
    x.status="queued"; x.stage=None; x.progress=0; x.retries+=1; db.commit(); db.close()
    async def execute():
        async with app.state.sem: await asyncio.to_thread(Pipeline().run,jid)
    asyncio.create_task(execute()); return {"id":jid,"status":"queued","retries":x.retries}
@app.post("/api/jobs/{jid}/priority/{priority}")
def reorder(jid:str,priority:int):
    db=SessionLocal(); x=db.get(Job,jid)
    if not x: db.close(); raise HTTPException(404,"Job not found")
    x.priority=priority; db.commit(); db.close(); return {"id":jid,"priority":priority}
