import json
class OpenAITranslator:
    def __init__(self,api_key,model):
        from openai import OpenAI
        self.client=OpenAI(api_key=api_key); self.model=model
    def translate(self,transcript,target_language):
        payload=[{"id":s["id"],"text":s["text"]} for s in transcript["segments"]]
        prompt=("Translate spoken dialogue into the user-specified target language. "
        "Preserve names, places, terminology, cultural meaning and intent. Do not invent dialogue. "
        "You may combine or split source segments (N:M). Return JSON array with source_ids and text. "
        f"Target language: {target_language}\nSource: {json.dumps(payload,ensure_ascii=False)}")
        r=self.client.responses.create(model=self.model,input=prompt)
        text=r.output_text
        return json.loads(text)
class IdentityTranslator:
    def translate(self,transcript,target_language):
        return [{"source_ids":[s["id"]],"text":s["text"]} for s in transcript["segments"]]
