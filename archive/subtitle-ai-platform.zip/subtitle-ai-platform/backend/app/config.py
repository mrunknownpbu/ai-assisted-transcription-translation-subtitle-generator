import os
from dataclasses import dataclass

@dataclass(frozen=True)
class Settings:
    database_url: str = os.getenv("DATABASE_URL", "sqlite:////data/subtitle_ai.db")
    media_root: str = os.getenv("MEDIA_ROOT", "/media")
    input_root: str = os.getenv("INPUT_ROOT", "/input")
    output_root: str = os.getenv("OUTPUT_ROOT", "/output")
    work_root: str = os.getenv("WORK_ROOT", "/work")
    asr_primary: str = os.getenv("ASR_PRIMARY", "faster-whisper")
    asr_fallbacks: tuple[str,...] = tuple(x.strip() for x in os.getenv("ASR_FALLBACKS", "vosk,whisper-api").split(",") if x.strip())
    whisper_model: str = os.getenv("WHISPER_MODEL", "small")
    whisper_device: str = os.getenv("WHISPER_DEVICE", "auto")
    whisper_compute_type: str = os.getenv("WHISPER_COMPUTE_TYPE", "auto")
    translation_provider: str = os.getenv("TRANSLATION_PROVIDER", "openai")
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-5-mini")
    worker_concurrency: int = int(os.getenv("WORKER_CONCURRENCY", "1"))
    max_retries: int = int(os.getenv("MAX_RETRIES", "2"))

settings=Settings()
