import os,uuid,traceback
from pathlib import Path
from .config import settings
from .db import SessionLocal,Job,LogEvent,Decision
from .hardware import detect_hardware
from .media import inspect_media,stream_identity,extract_audio
from .stages import rank_audio_streams,FasterWhisperEngine,VoskEngine,WhisperAPIEngine,ASRRouter,hallucination_defense,conservative_normalize,project_target_segments
from .translation import OpenAITranslator,IdentityTranslator
from .output import write_srt,write_vtt,burn_in

class Pipeline:
    def __init__(self): self.hw=detect_hardware()
    def check_cancel(self,db,job):
        db.refresh(job)
        if job.status=="cancel_requested":
            job.status="cancelled"; db.commit(); raise RuntimeError("Job cancelled by user")
    def log(self,db,jid,stage,level,msg,data=None): db.add(LogEvent(job_id=jid,stage=stage,level=level,message=msg,data=data or {})); db.commit()
    def run(self,jid):
        db=SessionLocal(); job=db.get(Job,jid)
        try:
            job.status="running"; job.hardware_profile=self.hw; db.commit()
            self.log(db,jid,"inspection","info","Inspecting source media")
            info=inspect_media(job.input_path); job.stage="media_inspection"; job.progress=0.05; db.commit(); self.check_cancel(db,job)
            if not info["audio_streams"]: raise RuntimeError("No audio streams found")
            ranks=rank_audio_streams(info)
            stream=next((s for s in info["audio_streams"] if s["index"]==job.selected_stream),None) if job.selected_stream is not None else info["audio_streams"][0]
            if job.selected_stream is None: stream=max(info["audio_streams"],key=lambda s: next(x["score"] for x in ranks if x["stream_index"]==s["index"]))
            key=stream_identity(job.input_path,stream); self.log(db,jid,"stream_selection","info","Selected audio stream",{"stream":stream["index"],"rankings":ranks,"stream_hash":key})
            job.selected_stream=stream["index"]; job.stage="stream_selection"; job.progress=.12; db.commit()
            work=Path(settings.work_root)/jid; work.mkdir(parents=True,exist_ok=True); audio=str(work/"audio.wav"); extract_audio(job.input_path,stream["index"],audio)
            job.stage="language_detection"; job.progress=.18; db.commit()
            # Language is determined by ASR when auto. Manual value is passed through.
            job.stage="asr"; job.progress=.25; db.commit()
            engines=[]
            names=[settings.asr_primary,*settings.asr_fallbacks]
            for n in names:
                if n=="faster-whisper": engines.append(FasterWhisperEngine(settings.whisper_model,settings.whisper_device,settings.whisper_compute_type))
                elif n=="vosk": engines.append(VoskEngine())
                elif n=="whisper-api":
                    if settings.openai_api_key:
                        from openai import OpenAI; engines.append(WhisperAPIEngine(OpenAI(api_key=settings.openai_api_key)))
            self.check_cancel(db,job); result=ASRRouter(engines).transcribe(audio,job.source_language)
            job.source_language=job.source_language or result["language"]; job.provenance={"stream_index":stream["index"],"stream_hash":key,"asr":result.get("engine"),"asr_model":result.get("model"),"hardware":self.hw}; db.commit()
            self.log(db,jid,"asr","info","ASR completed",result.get("attempts",[]))
            job.stage="hallucination_defense"; job.progress=.55; db.commit()
            clean,decisions=hallucination_defense(result); [db.add(Decision(job_id=jid,stage="hallucination_defense",decision=d["decision"],reason=d["reason"],threshold=d["threshold"])) for d in decisions]; db.commit()
            normalized=conservative_normalize(clean); job.stage="translation"; job.progress=.65; db.commit()
            provider=OpenAITranslator(settings.openai_api_key,settings.openai_model) if settings.translation_provider=="openai" and settings.openai_api_key else IdentityTranslator()
            self.check_cancel(db,job); translations=provider.translate(normalized,job.target_language)
            job.stage="timing_projection"; job.progress=.82; db.commit()
            target=project_target_segments(normalized,translations)
            outdir=Path(settings.output_root)/jid; outdir.mkdir(parents=True,exist_ok=True); stem=Path(job.input_path).stem
            prov={**job.provenance,"source_language":job.source_language,"target_language":job.target_language,"pipeline":"audio-first","evidence_policy":"subtitles/metadata are evidence only"}
            outputs={}
            if "srt" in job.outputs: outputs["srt"]=str(outdir/f"{stem}.srt"); write_srt(target,outputs["srt"],prov)
            if "vtt" in job.outputs: outputs["vtt"]=str(outdir/f"{stem}.vtt"); write_vtt(target,outputs["vtt"],prov)
            if "webvtt" in job.outputs: outputs["webvtt"]=str(outdir/f"{stem}.webvtt"); write_vtt(target,outputs["webvtt"],prov)
            if "burned" in job.outputs:
                if "srt" not in outputs: outputs["srt"]=str(outdir/f"{stem}.srt"); write_srt(target,outputs["srt"],prov)
                outputs["burned"]=str(outdir/f"{stem}.burned.mp4"); burn_in(job.input_path,outputs["srt"],outputs["burned"])
            job.outputs=outputs; job.stage="qc"; job.progress=.96; db.commit()
            # Basic deterministic QC; failures are explicit.
            for s in target:
                if s["end"]<=s["start"]: raise RuntimeError(f"QC failed: non-positive cue duration {s['id']}")
            job.status="completed"; job.progress=1; job.stage="done"; db.commit(); self.log(db,jid,"qc","info","QC passed",{"cue_count":len(target)})
        except Exception as e:
            job.status="failed"; job.stage=job.stage or "unknown"; job.provenance={**(job.provenance or {}),"error":str(e),"traceback":traceback.format_exc()}; db.commit(); self.log(db,jid,job.stage or "unknown","error",str(e)); raise
        finally: db.close()
