import json, platform, shutil, subprocess, os
from dataclasses import asdict, dataclass
@dataclass
class GPU:
    vendor:str; name:str; memory_mb:int|None; device_id:str
@dataclass
class HardwareProfile:
    cpu:str; cores:int; ram_mb:int|None; gpus:list[GPU]; accelerators:list[str]
def _cmd(cmd):
    try:return subprocess.check_output(cmd,stderr=subprocess.DEVNULL,text=True,timeout=3).strip()
    except Exception:return ""
def detect_hardware()->dict:
    gpus=[]
    nvsmi=shutil.which("nvidia-smi")
    if nvsmi:
        out=_cmd([nvsmi,"--query-gpu=index,name,memory.total","--format=csv,noheader,nounits"])
        for line in out.splitlines():
            p=[x.strip() for x in line.split(",")]
            if len(p)>=3:
                try: mem=int(p[2])
                except: mem=None
                gpus.append(asdict(GPU("nvidia",p[1],mem,p[0])))
    roc=shutil.which("rocminfo")
    if roc and not gpus:
        out=_cmd([roc])
        if "Name:" in out:
            gpus.append(asdict(GPU("amd-rocm","ROCm accelerator",None,"rocm0")))
    ram=None
    try: ram=int(os.sysconf("SC_PHYS_PAGES")*os.sysconf("SC_PAGE_SIZE")/1048576)
    except: pass
    p=HardwareProfile(platform.processor() or platform.machine(),os.cpu_count() or 1,ram,gpus,[g["vendor"] for g in gpus])
    return asdict(p)
