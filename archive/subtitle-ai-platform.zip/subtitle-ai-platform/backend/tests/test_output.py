from app.output import write_srt,write_vtt
def test_formats(tmp_path):
    seg=[{"start":0,"end":1.25,"text":"Hello"}]; p={"stream_index":2}; s=tmp_path/"a.srt"; v=tmp_path/"a.vtt"; write_srt(seg,s,p); write_vtt(seg,v,p); assert "00:00:00,000 --> 00:00:01,250" in s.read_text(); assert v.read_text().startswith("WEBVTT")
