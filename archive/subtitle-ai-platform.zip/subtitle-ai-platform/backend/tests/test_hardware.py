from app.hardware import detect_hardware
def test_hardware_shape():
    x=detect_hardware(); assert "cpu" in x and "cores" in x and "gpus" in x
