from app.stages import hallucination_defense,project_target_segments,conservative_normalize,ASRRouter
class Bad:
    name="bad"
    def transcribe(self,audio,language=None): raise RuntimeError("down")
class Good:
    name="good"
    def transcribe(self,audio,language=None): return {"text":"hi","segments":[],"language":"en"}
def test_fallback(): assert ASRRouter([Bad(),Good()]).transcribe("x")["attempts"][-1]=="good"
def test_recall_first_keeps_low_confidence():
    t={"segments":[{"id":"s1","start":0,"end":1,"text":"hello there","words":[{"text":"hello","start":0,"end":.5,"confidence":.1},{"text":"there","start":.5,"end":1,"confidence":.1}]}]}; clean,d=hallucination_defense(t,min_conf=.2); assert len(clean["segments"])==1
def test_repetition_with_low_confidence_suppressed():
    txt="x x x x x x"; t={"segments":[{"id":"s1","start":0,"end":1,"text":txt,"words":[{"text":"x","start":i/6,"end":(i+1)/6,"confidence":.1} for i in range(6)]}]} ; clean,d=hallucination_defense(t); assert not clean["segments"]; assert d[0]["decision"]=="suppress"
def test_n_to_m_projection():
    t={"segments":[{"id":"a","words":[{"start":1,"end":2}]},{"id":"b","words":[{"start":2,"end":3}]}]}; out=project_target_segments(t,[{"source_ids":["a","b"],"text":"combined"}]); assert out[0]["start"]==1 and out[0]["end"]==3
def test_normalization_preserves_original():
    t={"segments":[{"id":"s","text":" hi  there ","words":[]}]}; n=conservative_normalize(t); assert n["segments"][0]["original_text"]==" hi  there " and n["segments"][0]["text"]=="hi there"
