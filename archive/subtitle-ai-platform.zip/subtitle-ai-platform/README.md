# Subtitle AI Platform

Production-oriented, audio-first subtitle generation platform. Batch processing is primary; input sources are abstracted so live/stream ingestion can be added without changing the core pipeline.

## Design guarantees

- Source media is mounted read-only and is never modified.
- Existing subtitles, filenames and metadata are evidence only; they never enter ASR or translation context.
- Every stage emits provenance and structured audit events.
- Audio stream cache keys include stream identity, codec and a content fingerprint.
- Hallucination filtering is recall-first: weak dialogue is retained unless there is positive evidence of hallucination.
- Timing is projected only from ASR word timestamps; no global subtitle shifts.
- Target language is an arbitrary user string; there is no hard-coded language allow-list.
- Whisper/faster-whisper is primary; fallback engines are configurable.

## Quick start

```bash
cp .env.example .env
mkdir -p data/{media,output,work,db}
docker compose up -d --build
```

CPU-only is the default. For NVIDIA Container Toolkit hosts:

```bash
docker compose -f docker-compose.yml -f docker-compose.nvidia.yml up -d --build
```

Open `http://localhost:8080`. API docs are at `http://localhost:8000/docs`.

## Input

The container reads `/media` read-only. Place source media in `data/media`. Outputs are written to `data/output`.

## ASR fallback

The router attempts the configured primary engine, then alternatives in order. Each attempt and failure is recorded. Built-in adapters are provided for faster-whisper, Vosk and a Whisper-compatible HTTP/API deployment.

## Hardware

At startup the backend probes NVIDIA (`nvidia-smi`), AMD ROCm (`rocminfo`) and generic CPU information. Hardware profile and per-job allocation are stored in SQLite.

## Tests

```bash
cd backend
python -m pytest -q
```

## Production notes

For a production deployment, place the frontend behind TLS/reverse proxy, back up `data/db`, use a dedicated work filesystem, set worker concurrency according to GPU VRAM, and pin image/dependency versions after validation in your environment.
