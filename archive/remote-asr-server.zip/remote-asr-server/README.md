# remote-asr-server

A small standalone ASR HTTP service, meant to run on a **different
machine** from the main subtitle-ai deployment — typically one with a
newer GPU (real `float16` tensor-core support) than the main
deployment's own hardware. See `server.py`'s module docstring for the
request/response contract with `subtitle_ai/asr.py`'s `_transcribe_remote()`.

Not part of the main Docker image — it's a separate process, run
directly on the remote machine (e.g. via WSL2 on Windows).

## Setup (WSL2 on Windows)

1. Install WSL2 with an Ubuntu distro if not already present, and the
   [NVIDIA CUDA driver for WSL](https://docs.nvidia.com/cuda/wsl-user-guide/)
   (the Windows-side GPU driver already provides this; no separate
   in-WSL driver install is needed, only the CUDA toolkit/runtime).
2. Inside WSL2, from this directory: `bash setup.sh` — automates the
   venv, dependency install, ffmpeg, and pre-downloading `large-v3` (see
   that script's own comments). This part doesn't change once the
   multi-node pull redesign replaces the push-based server below.
3. **Steps 3-6 below are push-model-specific and will change** once the
   Tdarr-style multi-node pull design lands (nodes will register
   themselves outbound instead of the server calling a fixed address --
   no firewall port-forwarding will be needed at all). Hold off on these
   until that's ready. For now, to run the current push-based server:
   ```bash
   export REMOTE_ASR_TOKEN=<a long random string>
   uvicorn server:app --host 0.0.0.0 --port 8090
   ```
   First request will download `large-v3` into the default
   huggingface cache (unlike the main deployment, this machine isn't
   sandboxed to a read-only `/models` mount, so the normal
   huggingface_hub cache is fine).
4. **Windows Firewall**: allow inbound TCP on the chosen port from your
   LAN (Windows Defender Firewall -> Advanced Settings -> Inbound Rules
   -> New Rule -> Port -> TCP -> the port above).
5. Confirm reachability from the Linux server:
   ```bash
   curl http://<windows-lan-ip>:8090/health
   ```
6. On the Linux server, set in `/opt/docker/compose/.env`:
   ```
   SUBTITLE_AI_REMOTE_ASR_URL=http://<windows-lan-ip>:8090
   SUBTITLE_AI_REMOTE_ASR_TOKEN=<the same long random string>
   ```
   then redeploy (`docker compose up -d --build`).

## Running it persistently

`uvicorn server:app ...` run directly in a terminal dies when that
terminal/WSL session closes. For a server "normally left on and idle",
run it as a proper background service instead — either a systemd user
service inside WSL2 (Ubuntu on WSL2 supports systemd since 2022;
`systemctl --user enable/start`), or a Windows Scheduled Task that
launches `wsl.exe -d Ubuntu -- <activate venv and run uvicorn>` at
startup.

## Behavior when this service is unreachable

The main deployment falls back to local (P4) transcription automatically
— see `subtitle_ai/asr.py`'s `AsrConfig.remote_url` docstring. Nothing
on this side needs to signal that; a connection refused/timeout is
enough.
