#!/usr/bin/env bash
# Automates the WSL2-side setup steps from README.md that DON'T change
# once the multi-node pull architecture replaces the current push-based
# server.py -- Python env, dependencies, ffmpeg, and pre-downloading the
# large-v3 model (so the first real request doesn't stall on a multi-GB
# download). Deliberately does NOT touch Windows Firewall or write any
# SUBTITLE_AI_REMOTE_ASR_URL config -- those are push-model-specific and
# will be replaced by the node's own outbound registration once the pull
# redesign lands (see the Linux-side conversation this script's setup was
# planned in). Run from inside WSL2, from this directory:
#   bash setup.sh
set -euo pipefail
cd "$(dirname "$0")"

echo "== Checking for an NVIDIA GPU visible inside WSL2 =="
if ! command -v nvidia-smi >/dev/null 2>&1; then
    echo "nvidia-smi not found. This means the NVIDIA CUDA driver for WSL"
    echo "isn't set up yet (installed on the WINDOWS side, not inside WSL2 --"
    echo "see https://docs.nvidia.com/cuda/wsl-user-guide/). Fix that first,"
    echo "then re-run this script." >&2
    exit 1
fi
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader

echo "== Installing ffmpeg (needed for language-probe window extraction) =="
sudo apt-get update -qq
sudo apt-get install -y -qq ffmpeg python3-venv >/dev/null

echo "== Creating Python virtualenv (.venv) =="
python3 -m venv .venv
source .venv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt

echo "== Verifying CUDA is visible to ctranslate2 and pre-downloading large-v3 =="
echo "   (this downloads several GB on first run -- expect it to take a while)"
python3 -c "
from faster_whisper import WhisperModel
model = WhisperModel('large-v3', device='cuda', compute_type='float16')
print('OK: large-v3 loaded on', model.model.device if hasattr(model, 'model') else 'cuda')
"

echo
echo "== Done =="
echo "Environment is ready at $(pwd)/.venv"
echo "Do NOT start the server or open firewall ports yet -- those steps"
echo "are being replaced by the multi-node pull design. Once that's ready"
echo "you'll be given an updated start command instead of 'uvicorn server:app ...'."
