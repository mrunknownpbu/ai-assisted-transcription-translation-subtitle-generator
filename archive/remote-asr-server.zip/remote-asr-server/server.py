"""Standalone remote ASR service -- runs on a SEPARATE machine from the
main subtitle-ai deployment (see subtitle_ai/asr.py's AsrConfig.remote_url
and _transcribe_remote()), typically one with a newer GPU than the main
deployment's own hardware. Intended to run under WSL2 on a Windows box
with an NVIDIA GPU that supports efficient float16 (unlike this project's
own Tesla P4 deployment, which is limited to int8 -- see asr.py's
AsrConfig.compute_type).

Deliberately standalone, not a subtitle_ai package import: this process
runs on a different machine, outside that package entirely, so
detect_dominant_language()/_majority_language() are ported here rather
than shared -- a documented duplication, not an oversight. Keep the two
in sync by hand if the language-detection algorithm changes on either
side; see subtitle_ai/asr.py's own copy for the real defect history
those functions carry in their comments (multi-window majority vote,
duplicate-offset dedup, broad exception handling).

Contract with the caller (subtitle_ai/asr.py's _transcribe_remote()):
  POST /transcribe?<AsrConfig fields as query params>, raw WAV bytes as
  the request body, `Authorization: Bearer <token>` if REMOTE_ASR_TOKEN
  is set. Returns {"language", "language_probability", "duration",
  "segments": [...]} where `segments` is EXACTLY the shape
  subtitle_ai/asr.py's segments_from_raw() already parses.
"""

from __future__ import annotations

import asyncio
import os
import tempfile
from pathlib import Path

from fastapi import FastAPI, Header, HTTPException, Query, Request
from fastapi.responses import JSONResponse

MODEL_NAME = os.environ.get("REMOTE_ASR_MODEL", "large-v3")
# float16, not int8: the whole point of offloading here is a GPU that
# actually supports efficient float16 (confirmed on the intended target
# hardware -- an RTX 3080, Ampere, full tensor-core float16 throughput),
# unlike the main deployment's Tesla P4.
COMPUTE_TYPE = os.environ.get("REMOTE_ASR_COMPUTE_TYPE", "float16")
AUTH_TOKEN = os.environ.get("REMOTE_ASR_TOKEN")  # None = no auth check

LANGUAGE_PROBE_WINDOW_DURATION = 20.0
LANGUAGE_PROBE_FRACTIONS = (0.10, 0.30, 0.50, 0.70, 0.90)

app = FastAPI(title="remote-asr-server")
_model_lock = asyncio.Lock()
_state: dict = {}


def _get_model():
    if "model" not in _state:
        from faster_whisper import WhisperModel
        _state["model"] = WhisperModel(MODEL_NAME, device="cuda", compute_type=COMPUTE_TYPE)
    return _state["model"]


def _wav_duration_seconds(wav_path: str) -> float:
    import wave
    with wave.open(wav_path, "rb") as f:
        return f.getnframes() / float(f.getframerate())


def _extract_wav_window(wav_path: str, offset: float, duration: float, out_path: str) -> None:
    import subprocess
    command = ["ffmpeg", "-y", "-ss", str(offset), "-t", str(duration), "-i", wav_path,
              "-ac", "1", "-ar", "16000", out_path]
    subprocess.run(command, capture_output=True, text=True, timeout=60, check=True)


def _majority_language(votes: list[tuple[str, float]]) -> tuple[str, float] | None:
    """Ported from subtitle_ai/asr.py -- see that copy's comments for the
    real defect history (agreement-weighted confidence, not just the
    winning windows' own mean)."""
    if not votes:
        return None
    by_language: dict[str, list[float]] = {}
    for lang, conf in votes:
        by_language.setdefault(lang, []).append(conf)
    winner = max(by_language, key=lambda lang: (len(by_language[lang]), sum(by_language[lang]) / len(by_language[lang])))
    confidences = by_language[winner]
    mean_confidence = sum(confidences) / len(confidences)
    agreement = len(confidences) / len(votes)
    return winner, mean_confidence * agreement


def _detect_dominant_language(model, wav_path: str) -> tuple[str, float] | None:
    """Ported from subtitle_ai/asr.py's detect_dominant_language() -- same
    multi-window majority vote, same duplicate-offset dedup, same broad
    per-window exception handling (a probe window is best-effort, never
    allowed to abort the others or crash the request)."""
    try:
        duration = _wav_duration_seconds(wav_path)
    except OSError:
        return None
    if duration <= LANGUAGE_PROBE_WINDOW_DURATION:
        return None
    votes: list[tuple[str, float]] = []
    seen_offsets: set[float] = set()
    with tempfile.TemporaryDirectory() as tmp:
        for i, fraction in enumerate(LANGUAGE_PROBE_FRACTIONS):
            offset = max(0.0, min(duration - LANGUAGE_PROBE_WINDOW_DURATION, fraction * duration))
            if offset in seen_offsets:
                continue
            seen_offsets.add(offset)
            clip_path = str(Path(tmp) / f"probe_{i}.wav")
            try:
                _extract_wav_window(wav_path, offset, LANGUAGE_PROBE_WINDOW_DURATION, clip_path)
                segments, info = model.transcribe(clip_path, beam_size=1, vad_filter=True,
                                                  word_timestamps=False)
                segments = list(segments)
                if any(s.text.strip() for s in segments):
                    votes.append((info.language, float(info.language_probability)))
            except Exception:
                continue
    return _majority_language(votes)


def _check_auth(authorization: str | None) -> None:
    if AUTH_TOKEN is None:
        return
    if authorization != f"Bearer {AUTH_TOKEN}":
        raise HTTPException(status_code=401, detail="invalid or missing bearer token")


@app.get("/health")
def health():
    return {"ok": True, "model": MODEL_NAME, "compute_type": COMPUTE_TYPE}


@app.post("/transcribe")
async def transcribe(
    request: Request,
    beam_size: int = Query(5), temperature: str = Query("0.0,0.2,0.4,0.6,0.8,1.0"),
    compression_ratio_threshold: float = Query(2.4), logprob_threshold: float = Query(-1.0),
    no_speech_threshold: float = Query(0.6), condition_on_previous_text: bool = Query(False),
    vad_filter: bool = Query(True), word_timestamps: bool = Query(True),
    language: str | None = Query(None), hotwords: str | None = Query(None),
    authorization: str | None = Header(None),
):
    _check_auth(authorization)
    body = await request.body()
    async with _model_lock:
        # One request's model call at a time -- the caller (this
        # deployment's own worker) is single-job-at-a-time already, so
        # this is defense in depth against any client sending overlapping
        # requests, not a scenario expected in normal operation.
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            f.write(body)
            wav_path = f.name
        try:
            model = await asyncio.to_thread(_get_model)
            effective_language = language
            language_probability_override = None
            if effective_language is None:
                probe_result = await asyncio.to_thread(_detect_dominant_language, model, wav_path)
                if probe_result is not None:
                    effective_language, language_probability_override = probe_result

            def _run():
                segments_iter, info = model.transcribe(
                    wav_path, beam_size=beam_size, temperature=[float(x) for x in temperature.split(",")],
                    compression_ratio_threshold=compression_ratio_threshold,
                    log_prob_threshold=logprob_threshold, no_speech_threshold=no_speech_threshold,
                    condition_on_previous_text=condition_on_previous_text,
                    vad_filter=vad_filter, word_timestamps=word_timestamps,
                    language=effective_language, hotwords=hotwords or None)
                raw = []
                for seg in segments_iter:
                    raw.append({
                        "start": seg.start, "end": seg.end,
                        "avg_logprob": seg.avg_logprob, "no_speech_prob": seg.no_speech_prob,
                        "compression_ratio": seg.compression_ratio,
                        "words": [{"word": w.word, "start": w.start, "end": w.end, "probability": w.probability}
                                 for w in (seg.words or [])],
                    })
                return raw, info

            raw, info = await asyncio.to_thread(_run)
            reported_probability = (language_probability_override
                                    if language_probability_override is not None
                                    else getattr(info, "language_probability", None))
            return JSONResponse({"language": info.language, "language_probability": reported_probability,
                                 "duration": getattr(info, "duration", None), "segments": raw})
        finally:
            os.unlink(wav_path)
