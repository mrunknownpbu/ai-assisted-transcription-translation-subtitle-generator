import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

const API = '/api';

const iconPaths = {
  home: 'M3 10.5 12 3l9 7.5v9a1.5 1.5 0 0 1-1.5 1.5h-5v-6h-5v6h-5A1.5 1.5 0 0 1 3 19.5v-9Z',
  plus: 'M12 5v14M5 12h14',
  list: 'M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01',
  clock: 'M12 7v5l3 2M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z',
  folder: 'M3 6.5A2.5 2.5 0 0 1 5.5 4H10l2 2h6.5A2.5 2.5 0 0 1 21 8.5v9A2.5 2.5 0 0 1 18.5 20h-13A2.5 2.5 0 0 1 3 17.5v-11Z',
  settings: 'M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7ZM19.4 15a1.8 1.8 0 0 0 .36 1.98l.06.06-1.9 1.9-.06-.06a1.8 1.8 0 0 0-1.98-.36 1.8 1.8 0 0 0-1.1 1.66V20h-2.68v-.08a1.8 1.8 0 0 0-1.1-1.66 1.8 1.8 0 0 0-1.98.36l-.06.06-1.9-1.9.06-.06A1.8 1.8 0 0 0 7.4 15a1.8 1.8 0 0 0-1.66-1.1H5.65v-2.68h.09A1.8 1.8 0 0 0 7.4 10a1.8 1.8 0 0 0-.36-1.98l-.06-.06 1.9-1.9.06.06a1.8 1.8 0 0 0 1.98.36 1.8 1.8 0 0 0 1.1-1.66V4.7h2.68v.12a1.8 1.8 0 0 0 1.1 1.66 1.8 1.8 0 0 0 1.98-.36l.06-.06 1.9 1.9-.06.06A1.8 1.8 0 0 0 19.4 10a1.8 1.8 0 0 0 1.66 1.1h.09v2.68h-.09A1.8 1.8 0 0 0 19.4 15Z',
  cpu: 'M8 8h8v8H8zM5 10H3m2 4H3m16-4h-2m2 4h-2M10 5V3m4 2V3m-4 18v-2m4 2v-2M6 6h12v12H6z',
  file: 'M6 3h8l4 4v14H6zM14 3v5h5M9 13h6M9 17h6',
  search: 'm20 20-4.5-4.5M10.5 17a6.5 6.5 0 1 1 0-13 6.5 6.5 0 0 1 0 13Z',
  moon: 'M20 15.5A8.5 8.5 0 0 1 8.5 4 8.5 8.5 0 1 0 20 15.5Z',
  bell: 'M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4',
  upload: 'M12 16V4m0 0-5 5m5-5 5 5M5 16v2a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-2',
  play: 'm9 6 10 6-10 6V6Z',
  download: 'M12 4v11m0 0 5-5m-5 5-5-5M5 20h14',
  refresh: 'M20 11a8 8 0 1 0 1 4M20 5v6h-6',
  check: 'm5 12 4 4L19 6',
  x: 'M6 6l12 12M18 6 6 18',
  chevron: 'm7 10 5 5 5-5',
  info: 'M12 17v-5M12 8h.01M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z',
  globe: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0-18c2.2 2.2 3.3 5.2 3.3 9S14.2 18.8 12 21c-2.2-2.2-3.3-5.2-3.3-9S9.8 5.2 12 3ZM3 12h18',
  mic: 'M12 14a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v5a3 3 0 0 0 3 3Zm-7-3a7 7 0 0 0 14 0M12 18v3M9 21h6',
  zap: 'm13 2-9 12h7l-2 8 9-12h-7l2-8Z',
  eye: 'M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Zm10 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z',
  log: 'M5 4h14v16H5zM8 8h8M8 12h8M8 16h5',
  harddrive: 'M4 6h16v12H4zM4 10h16M8 15h.01M12 15h.01',
  more: 'M5 12h.01M12 12h.01M19 12h.01',
  external: 'M14 4h6v6M20 4l-9 9M18 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h5',
};

function Icon({ name, size = 18, stroke = 1.8, className = '' }) {
  return <svg className={`icon ${className}`} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"><path d={iconPaths[name] || iconPaths.info} /></svg>;
}

const demoJobs = [
  { id: 1, title: 'Sen Cal Kapimi S02E01.mkv', stage: 'Transcribing (Whisper)', progress: 35, status: 'running', eta: '12 min', thumb: 'couple', source: 'Turkish', target: 'English' },
  { id: 2, title: 'The Last of Us S01E01.mp4', stage: 'Waiting…', progress: 0, status: 'queued', eta: '—', thumb: 'lastofus', source: 'English', target: 'Malay' },
  { id: 3, title: 'Breaking Bad S01E01.mkv', stage: 'Waiting…', progress: 0, status: 'queued', eta: '—', thumb: 'breaking', source: 'English', target: 'Malay' },
];

const recentJobs = [
  { title: 'Wednesday S01E01.mkv', status: 'Completed', when: '2 hours ago', thumb: 'wednesday' },
  { title: 'One Piece S01E01.mp4', status: 'Completed', when: '5 hours ago', thumb: 'onepiece' },
  { title: 'Avatar The Last Airbender.mkv', status: 'Failed', when: '1 day ago', thumb: 'avatar' },
];

const logs = [
  ['14:23:15', 'INFO', 'Starting job: Sen Cal Kapimi S02E01.mkv'],
  ['14:23:16', 'INFO', 'Inspecting media file…'],
  ['14:23:18', 'INFO', 'Found 3 audio streams'],
  ['14:23:19', 'INFO', 'Auto-selecting best audio stream…'],
  ['14:23:20', 'INFO', 'Detecting spoken language…'],
  ['14:23:25', 'INFO', 'Language detected: Turkish (92%)'],
  ['14:23:26', 'INFO', 'Starting transcription (Whisper)…'],
  ['14:24:10', 'PROGRESS', 'Transcribing… 35%'],
  ['14:24:10', 'INFO', 'Processing segment 124/356…'],
];

function Poster({ type, className = '' }) {
  return <div className={`poster poster-${type} ${className}`}><div className="poster-glow" /><span>{type === 'couple' ? 'SÇ' : type === 'lastofus' ? 'TLOU' : type === 'breaking' ? 'BB' : type === 'wednesday' ? 'W' : type === 'onepiece' ? 'OP' : 'ATLA'}</span></div>;
}

function StatusDot({ tone = 'ok' }) { return <span className={`status-dot ${tone}`} />; }

function App() {
  const [activeNav, setActiveNav] = useState('Dashboard');
  const [tab, setTab] = useState('Language & Translation');
  const [form, setForm] = useState({ target: 'English', sourceMode: 'auto', source: 'Turkish', formats: ['srt', 'vtt', 'webvtt'], preserveNames: true, cultural: true, context: true, readability: true, original: false });
  const [jobs, setJobs] = useState(demoJobs);
  const [selectedJob, setSelectedJob] = useState(demoJobs[0]);
  const [processing, setProcessing] = useState(false);
  const [showMetadata, setShowMetadata] = useState(false);
  const [customFile, setCustomFile] = useState('');

  useEffect(() => {
    // The mockup remains usable without a backend. If the real API is available,
    // hydrate the queue from it without making the visual shell dependent on it.
    fetch(`${API}/jobs`).then(r => r.ok ? r.json() : null).then(data => {
      if (Array.isArray(data) && data.length) setJobs(data.map(j => ({ ...demoJobs[0], ...j, title: j.input_path?.split('/').pop() || demoJobs[0].title })));
    }).catch(() => {});
  }, []);

  const progress = processing ? 67 : selectedJob?.progress || 35;
  const outputLabel = useMemo(() => form.formats.length ? form.formats.map(x => x === 'burned' ? 'Burned-in' : x.toUpperCase()).join(', ') : 'None', [form.formats]);

  const toggleFormat = (key) => setForm(f => ({ ...f, formats: f.formats.includes(key) ? f.formats.filter(x => x !== key) : [...f.formats, key] }));
  const startProcessing = () => {
    setProcessing(true);
    setSelectedJob(j => ({ ...j, status: 'running', stage: 'Processing', progress: 67 }));
    setJobs(js => js.map(j => j.id === selectedJob.id ? { ...j, status: 'running', stage: 'Processing', progress: 67 } : j));
  };

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><span/><span/><span/><span/><span/></div><div><strong>SubtitleAI</strong><small>Transcribe · Translate · Subtitle</small></div></div>
      <nav className="nav">
        {['Dashboard','New Job','Job Queue','History','Media Library'].map((item, i) => <button key={item} className={`nav-item ${activeNav === item ? 'active' : ''}`} onClick={() => setActiveNav(item)}><Icon name={['home','plus','list','clock','folder'][i]} /> <span>{item}</span>{item === 'Job Queue' && <b className="badge">3</b>}</button>)}
      </nav>
      <div className="nav-section-label">SYSTEM</div>
      <nav className="nav"><button className={`nav-item ${activeNav === 'Hardware' ? 'active' : ''}`} onClick={() => setActiveNav('Hardware')}><Icon name="cpu"/><span>Hardware</span></button><button className={`nav-item ${activeNav === 'Logs' ? 'active' : ''}`} onClick={() => setActiveNav('Logs')}><Icon name="file"/><span>Logs</span></button><button className={`nav-item ${activeNav === 'Help' ? 'active' : ''}`} onClick={() => setActiveNav('Help')}><Icon name="info"/><span>Help</span></button></nav>
      <div className="sidebar-spacer" />
      <div className="storage-card"><div className="storage-head"><Icon name="harddrive"/><span>Storage Usage</span></div><div className="storage-value">1.2 TB <em>/ 3.6 TB</em></div><div className="progress-track"><i style={{width:'33%'}} /></div><div className="storage-pct">33%</div></div>
      <div className="profile"><div className="avatar">BA</div><div><strong>Badrul</strong><span>Administrator</span></div><Icon name="chevron" size={15}/></div>
    </aside>

    <div className="workspace">
      <header className="topbar"><div className="search"><Icon name="search" size={20}/><span>Search jobs, media, or files…</span><kbd>Ctrl + K</kbd></div><div className="top-actions"><span>v0.1.0</span><button aria-label="theme"><Icon name="moon"/></button><button aria-label="notifications" className="notify"><Icon name="bell"/><i/></button><span className="divider"/><StatusDot/><span>All Systems Operational</span></div></header>

      <main className="content">
        <section className="hero"><div className="hero-copy"><div className="eyebrow">SELF-HOSTED AI SUBTITLE PIPELINE</div><h1>Generate Subtitles with AI</h1><p>Accurate transcription. Natural translation. Precise timing.</p></div><div className="hero-features"><Feature icon="mic" title="Audio-First" text="Uses actual audio, not existing subtitles"/><Feature icon="globe" title="Any Language" text="Translate to any target language"/><Feature icon="zap" title="Multi-Engine" text="Whisper + fallback · CPU/GPU optimized"/></div></section>

        <section className="stepper"><Step n="1" label="Select Media" active/><Step n="2" label="Audio Stream"/><Step n="3" label="Language"/><Step n="4" label="Processing"/><Step n="5" label="Output"/></section>

        <div className="dashboard-grid">
          <div className="main-column">
            <section className="panel media-panel"><div className="panel-heading"><h2>New Job</h2><button className="ghost-btn"><Icon name="folder" size={16}/> Load from Library</button></div><div className="media-columns">
              <div className="upload-column"><h3>1. Select Media File</h3><p>Upload or browse media files to get started.</p><label className="dropzone"><Icon name="upload" size={38}/><strong>Drag & drop media files here</strong><span>or <u>click to browse</u></span><input type="file" accept="video/*,audio/*" onChange={e => setCustomFile(e.target.files?.[0]?.name || '')}/><small>Supports: MP4, MKV, MOV, AVI, WMV, FLV, M4V, TS, etc.<br/>No file size limit</small></label>{customFile && <div className="selected-mini"><Poster type="couple"/><div><strong>{customFile}</strong><span>Ready for inspection</span></div><Icon name="x" size={16}/></div>}{!customFile && <div className="selected-mini"><Poster type="couple"/><div><strong>Sen Cal Kapimi S02E01.mkv</strong><span>1.4 GB · Matroska (MKV)</span></div><button onClick={() => setCustomFile('')}>×</button></div>}</div>
              <div className="info-column"><div className="media-info-title"><h3>Media Information</h3></div><div className="file-summary"><Poster type="couple" className="large"/><div className="file-meta"><Row label="File Name" value="Sen Cal Kapimi S02E01.mkv"/><Row label="Format" value="Matroska (MKV)"/><Row label="Duration" value="00:42:16"/><Row label="Video" value="h264 (1920 × 1080, 25.000 fps)"/><Row label="Audio Streams" value="3"/><Row label="Subtitle Streams" value="2 (embedded)"/><Row label="File Size" value="1.4 GB"/></div></div><div className="metadata-action"><button className="ghost-btn" onClick={() => setShowMetadata(v => !v)}><Icon name="folder" size={15}/> View All Metadata</button><button className="icon-btn"><Icon name="info" size={15}/></button></div>{showMetadata && <div className="metadata-box">container: Matroska<br/>video codec: H.264 High@L4.1<br/>duration: 00:42:16.120<br/>streams: 6 total · 3 audio · 2 subtitle · 1 video<br/>source: read-only inspection</div>}
                <div className="stream-title"><h3>Audio Streams (3)</h3><button className="link-btn">Analyze Audio Streams <Icon name="chevron" size={14}/></button></div><div className="stream-table"><div className="stream-row header"><span>#</span><span>Language (detected)</span><span>Codec</span><span>Channels</span><span>Sample Rate</span><span>Bitrate</span><span/></div>{[['0','Turkish (92%)','AAC','2','48 kHz','256 kbps','ok'],['1','English (85%)','AC3','6','48 kHz','640 kbps','ok'],['2','Unknown (42%)','AAC','2','48 kHz','128 kbps','bad']].map((s,idx)=><div className="stream-row" key={s[0]}><span className="stream-radio"><input type="radio" name="stream" defaultChecked={idx===0}/></span><span><StatusDot tone={s[6]}/>{s[1]}</span><span>{s[2]}</span><span>{s[3]}</span><span>{s[4]}</span><span>{s[5]}</span><button className="play-btn"><Icon name="play" size={12}/> Play</button></div>)}</div></div>
            </div></section>

            <section className="panel settings-panel"><div className="tabs">{['Language & Translation','Processing Options','Output Options','Preview'].map((x,i)=><button key={x} className={tab===x?'active':''} onClick={() => setTab(x)}><Icon name={['globe','settings','file','eye'][i]} size={16}/>{x}</button>)}</div>{tab==='Language & Translation' ? <div className="settings-body"><div className="setting-box"><h3>Source Language</h3><label className="radio-line"><input type="radio" checked={form.sourceMode==='auto'} onChange={() => setForm(f=>({...f,sourceMode:'auto'}))}/><span><b>Auto-detect</b><small>Detected: Turkish (92% confidence)</small></span></label><label className="radio-line"><input type="radio" checked={form.sourceMode==='manual'} onChange={() => setForm(f=>({...f,sourceMode:'manual'}))}/><span><b>Manual selection</b><select value={form.source} onChange={e=>setForm(f=>({...f,source:e.target.value}))}><option>Turkish</option><option>English</option><option>Malay</option><option>Japanese</option><option>Korean</option></select></span></label></div><div className="setting-box"><h3>Target Language</h3><label className="radio-line"><input type="radio" checked readOnly/><span><b>Any language <small className="inline-note">(type or select)</small></b><div className="language-input"><Icon name="globe" size={15}/><input value={form.target} onChange={e=>setForm(f=>({...f,target:e.target.value}))}/><Icon name="x" size={14}/><Icon name="chevron" size={15}/></div><small>Supports any language pair. No fixed target list.</small></span></label><label className="radio-line muted"><input type="radio"/><span><b>Multiple languages <small>(batch mode)</small></b></span></label></div><div className="setting-box"><h3>Translation Options</h3>{[['preserveNames','Preserve proper names and places'],['cultural','Maintain cultural context'],['context','Use context-aware translation'],['readability','Optimize for subtitle readability'],['original','Include original text in output']].map(([key,label])=><label className="check-line" key={key}><input type="checkbox" checked={form[key]} onChange={e=>setForm(f=>({...f,[key]:e.target.checked}))}/><span>{label}</span></label>)}</div></div> : <div className="placeholder-tab"><Icon name="settings" size={30}/><h3>{tab}</h3><p>Mockup panel ready for the production controls from the project specification.</p></div>}</section>
          </div>

          <aside className="right-column">
            <section className="panel queue-panel"><div className="panel-heading"><h2>Processing Queue <span>(3)</span></h2><button className="primary-small"><Icon name="plus" size={16}/> New Job</button></div>{jobs.slice(0,3).map(j=><button className={`queue-item ${selectedJob?.id===j.id?'selected':''}`} key={j.id} onClick={()=>setSelectedJob(j)}><Poster type={j.thumb || 'couple'}/><div className="queue-content"><div className="queue-title"><strong>{j.title}</strong><Icon name="more" size={18}/></div>{j.status==='running'?<><div className="queue-progress"><i style={{width:`${j.progress||35}%`}}/><span>{j.progress||35}%</span></div><span className="queue-stage">{j.stage} <em>ETA {j.eta}</em></span></>:<span className="queued-pill">Queued</span>}{j.status==='queued' && <span className="queue-stage">Waiting…</span>}</div></button>)}</section>
            <section className="panel recent-panel"><div className="panel-heading"><h2>Recent Jobs</h2><button className="link-btn">View All</button></div>{recentJobs.map((j,i)=><div className="recent-item" key={j.title}><Poster type={j.thumb}/><div><strong>{j.title}</strong><span className={j.status==='Failed'?'failed':'completed'}><StatusDot tone={j.status==='Failed'?'bad':'ok'}/>{j.status} <em>· {j.when}</em></span></div><button className="icon-btn">{j.status==='Failed'?<Icon name="refresh" size={17}/>:<Icon name="download" size={17}/>}</button></div>)}</section>
          </aside>
        </div>

        <section className="bottom-grid"><div className="panel output-panel"><div className="panel-heading"><h2><Icon name="file" size={18}/> Output Settings</h2><button className="primary-action" onClick={startProcessing}><Icon name="play" size={15}/> {processing ? 'Processing…' : 'Start Processing'}</button></div><div className="output-grid"><div><label className="field-label">Target Language</label><div className="select-like"><span className="flag">🇬🇧</span><strong>{form.target}</strong><Icon name="chevron" size={15}/></div></div><div><label className="field-label">Output Formats</label><div className="format-checks">{[['srt','SRT'],['vtt','VTT'],['webvtt','WebVTT'],['burned','Burned-in Video']].map(([key,label])=><label key={key}><input type="checkbox" checked={form.formats.includes(key)} onChange={()=>toggleFormat(key)}/><span>{label}</span></label>)}</div></div><div><label className="field-label">Output Directory</label><div className="path-field"><Icon name="folder" size={15}/><span>/data/output</span><button>Browse</button></div></div></div><div className="advanced"><Icon name="settings" size={16}/><strong>Advanced Options</strong><Icon name="chevron" size={15}/></div></div><div className="run-summary panel"><button className="primary-action full" onClick={startProcessing}><Icon name="play" size={15}/> {processing ? 'Processing…' : 'Start Processing'}</button><SummaryRow icon="file" label="Selected file" value={customFile || 'Sen Cal Kapimi S02E01.mkv'}/><SummaryRow icon="globe" label="Source language" value={form.sourceMode==='auto' ? 'Auto-detect (Turkish)' : form.source}/><SummaryRow icon="globe" label="Target language" value={form.target || '—'}/><SummaryRow icon="file" label="Output formats" value={outputLabel}/><SummaryRow icon="zap" label="Processing engine" value="Whisper (with fallback)"/><button className="resource-link"><Icon name="external" size={14}/> Estimated time and resource usage</button></div></section>

        <section className="panel live-log"><div className="panel-heading"><h2><Icon name="log" size={18}/> Live Log</h2><button className="ghost-btn">Clear</button></div><div className="log-body">{logs.map(([time,level,text],i)=><div className="log-line" key={i}><time>{time}</time><b className={level.toLowerCase()}>{level}</b><span>{text}</span></div>)}</div></section>
      </main>
      <footer><span>SubtitleAI &nbsp; v0.1.0 &nbsp; | &nbsp; Open Source &nbsp; | &nbsp; Self-hosted &nbsp; | &nbsp; Audio is the source of truth. Always.</span><span>Built for media workflows</span></footer>
    </div>
  </div>;
}

function Feature({icon,title,text}){return <div className="feature"><div className="feature-icon"><Icon name={icon} size={22}/></div><div><strong>{title}</strong><span>{text}</span></div></div>}
function Step({n,label,active}){return <div className={`step ${active?'active':''}`}><div className="step-num">{n}</div><span>{label}</span></div>}
function Row({label,value}){return <div className="meta-row"><span>{label}</span><b>{value}</b></div>}
function SummaryRow({icon,label,value}){return <div className="summary-row"><Icon name={icon} size={16}/><span>{label}</span><b>{value}</b></div>}

createRoot(document.getElementById('root')).render(<App/>);
